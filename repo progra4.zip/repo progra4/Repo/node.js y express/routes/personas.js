const express = require('express');
const mongoose = require('mongoose');
var router = express.Router();

//llamado al modelo
const Persona = require('../models/persona');

//ruta de login
const loginRoute = "../views/pages/login";

router.get('/', (req, res) => {
    if(req.user) {
    res.render('pages/persona/addEdit', {
        viewTitle: 'New Persona'
    });
        }else {
            res.render(loginRoute, {
                message: "Please log in to continue",
                messageClass: "alert-danger",
        
    });
    }
});

router.post('/', (req, res) =>{
    if (req.user) {
        if(req.body._id == '')
        newPersona(req, res)
        else
        updatePersona(req, res)
      } else {
        res.render(loginRoute, {
          message: "Please log in to continue",
          messageClass: "alert-danger",
        });
      }
});




//método para insertar nuevo registro
function newPersona(req, res){
    var persona = new Persona();
    persona.personaId = req.body.personaId;
    persona.documento = req.body.documento;
    persona.nombre = req.body.nombre;
    persona.save((error) => {
        if(error)
        console.log("Error" + error);
        else
        res.redirect('persona/list');
    });
}

function updatePersona(req, res){
    Persona.findOneAndUpdate({_id: req.body._id}, req.body, {new: true}, (err, doc) => {
        if(!err){
            res.redirect('persona/list');
        } else {
            res.render('persona/addEdit', {
                viewTitle: "Update Persona",
                course: req.body
            })
        }
    })
}

router.get('/list', (req, res)=> {
    if(req.user){
    Persona.find((err, doc) => {
        if(!err){
            res.render('pages/persona/list', {
                list: doc,
                viewTitle: "Personas"
            })
        } else {
            console.log("Error" + err);
        }
    });
} else {
    res.render(loginRoute, {
      message: "Please log in to continue",
      messageClass: "alert-danger",
    });
  }

    
})

router.get('/:id', (req, res) => {
    if (req.user) {
        Persona.findById(req.params.id, (err, doc) => {
            if(!err){
                res.render('pages/persona/addEdit', {
                    viewTitle: "Update Persona",
                    persona: doc
                });
            }
        })
    } else {
        res.render(loginRoute, {
          message: "Please log in to continue",
          messageClass: "alert-danger",
        });
      }
})

router.get('/delete/:id', (req, res) => {
    if (req.user) {
        Persona.findByIdAndDelete(req.params.id, (err, doc) =>{
            if(!err){
                res.redirect('/persona/list');
            } else {
                console.log("Error" + err);
            }
        })
      } else {
        res.render(loginRoute, {
          message: "Please log in to continue",
          messageClass: "alert-danger",
        });
      }
})

module.exports = router;