const express = require('express');
const mongoose = require('mongoose');
var router = express.Router();

//llamado al modelo
const Vehiculo = require('../models/vehiculo');

//ruta de login
const loginRoute = "../views/pages/login";

router.get('/', (req, res) => {
    if(req.user) {
    res.render('pages/vehiculo/addEdit', {
        viewTitle: 'New Vehiculo'
    });
        }else {
            res.render(loginRoute, {
                message: "Please log in to continue",
                messageClass: "alert-danger",
        
    });
    }
});

router.post('/', (req, res) =>{
    if (req.user) {
        if(req.body._id == '')
        newVehiculo(req, res)
        else
        updateVehiculo(req, res)
      } else {
        res.render(loginRoute, {
          message: "Please log in to continue",
          messageClass: "alert-danger",
        });
      }
});




//método para insertar nuevo registro
function newVehiculo(req, res){
    var vehiculo = new Vehiculo();
    vehiculo.vehiculoId = req.body.vehiculoId;
    vehiculo.matricula = req.body.matricula;
    vehiculo.marca = req.body.marca;
    vehiculo.modelo = req.body.modelo;
    vehiculo.age = req.body.age;

    vehiculo.save((error) => {
        if(error)
        console.log("Error" + error);
        else
        res.redirect('vehiculo/list');
    });
}

function updateVehiculo(req, res){
    Vehiculo.findOneAndUpdate({_id: req.body._id}, req.body, {new: true}, (err, doc) => {
        if(!err){
            res.redirect('vehiculo/list');
        } else {
            res.render('vehiculo/addEdit', {
                viewTitle: "Update Vehiculo",
                course: req.body
            })
        }
    })
}

router.get('/list', (req, res)=> {
    if(req.user){
    Vehiculo.find((err, doc) => {
        if(!err){
            res.render('pages/vehiculo/list', {
                list: doc,
                viewTitle: "vehiculos"
            })
        } else {
            console.log("Error" + err);
        }
    });
} else {
    res.render(loginRoute, {
      message: "Please log in to continue",
      messageClass: "alert-danger",
    });
  }

    
})

router.get('/:id', (req, res) => {
    if (req.user) {
        Vehiculo.findById(req.params.id, (err, doc) => {
            if(!err){
                res.render('pages/vehiculo/addEdit', {
                    viewTitle: "Update Vehiculo",
                    vehiculo: doc
                });
            }
        })
    } else {
        res.render(loginRoute, {
          message: "Please log in to continue",
          messageClass: "alert-danger",
        });
      }
})

router.get('/delete/:id', (req, res) => {
    if (req.user) {
        Vehiculo.findByIdAndDelete(req.params.id, (err, doc) =>{
            if(!err){
                res.redirect('/vehiculo/list');
            } else {
                console.log("Error" + err);
            }
        })
      } else {
        res.render(loginRoute, {
          message: "Please log in to continue",
          messageClass: "alert-danger",
        });
      }
})

module.exports = router;