const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const personaSchema = new Schema({
    personaId: String,
    documento: String,    
    nombre: String
});

const Persona = mongoose.model('Persona', personaSchema);

module.exports = Persona;