const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const vehiculoSchema = new Schema({
    vehiculoId: String,
    matricula: String,    
    marca: String,
    modelo: String,    
    age: String
});

const Vehiculo = mongoose.model('Vehiculo', vehiculoSchema);

module.exports = Vehiculo;